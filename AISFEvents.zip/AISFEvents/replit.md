# Overview

The Weird Al Parody Generator is a Streamlit web application that creates music parodies with intelligent vocal synthesis. The system takes existing songs (via file upload or YouTube URL), separates vocals from instrumentals, and generates new vocal tracks based on custom parody lyrics with role-aware voice assignment (e.g., male quartet, single female). The application intelligently extends instrumental tracks to match longer parody lyrics and supports multi-voice arrangements.

**Current Status**: Fully functional MVP with all core features implemented (October 25, 2025)

# User Preferences

Preferred communication style: Simple, everyday language.

# Recent Changes

## October 25, 2025 - Initial Release
- Implemented complete parody generation pipeline
- Added spectral-based vocal separation using librosa HPSS and soft masking
- Built role-aware lyric parser with support for [Section](Role) annotations
- Integrated OpenAI TTS for multi-voice generation
- Created quartet effect simulation with pitch shifting and timing offsets
- Added BPM-aware instrumental extension
- Deployed Streamlit web interface with file upload and YouTube download

# System Architecture

## Frontend Architecture

**Technology Choice**: Streamlit-based web interface
- **Rationale**: Provides rapid development of interactive data applications with minimal frontend code
- **Key Features**: File upload, YouTube URL input, lyrics editor with role annotations, audio playback, and download functionality
- **UI Components**: Progress tracking, parsed lyric structure viewer, volume controls, audio player
- **Pros**: Fast prototyping, built-in UI components, Python-native, responsive design
- **Cons**: Limited customization compared to React/Vue frameworks

## Backend Architecture

**Modular Processing Pipeline**:
1. **Audio Acquisition** (`app.py`): Downloads audio from YouTube URLs using yt-dlp or accepts file uploads
2. **Audio Processing** (`audio_processor.py`): Separates vocals from instrumentals, detects BPM, extends instrumental tracks, creates quartet effects
3. **Lyric Parsing** (`lyric_parser.py`): Parses role-annotated lyrics into structured sections with role information
4. **Voice Generation** (`voice_generator.py`): Generates synthetic vocals using OpenAI TTS with role-specific voices and effects

### Core Modules

**audio_processor.py**:
- `separate_vocals()`: Uses librosa HPSS + spectral soft masking for vocal/instrumental separation
- `detect_bpm()`: Analyzes tempo using librosa beat tracking
- `estimate_lyrics_duration()`: Word-based duration estimation adjusted for BPM
- `extend_instrumental()`: BPM-aware looping that preserves bar boundaries
- `create_quartet_effect()`: Simulates 4-voice harmony with pitch shifts and timing offsets
- `mix_audio_tracks()`: Final mixing with adjustable volume levels

**lyric_parser.py**:
- Pattern: `\[Section\]\(Role\)` followed by lyrics
- Extracts section type, role, and lyrics text
- Cleans inline role markers and comments
- Supports roles: Male quartet, Single Female, Solo Female, Male, Male bass, Default

**voice_generator.py**:
- Voice bank with 6 OpenAI TTS voices mapped to roles
- Section-based vocal generation
- Automatic quartet effect application for group vocals
- Smooth transitions between sections with crossfades

**Vocal Separation Approach**:
- **Implementation**: Librosa-based HPSS (Harmonic-Percussive Source Separation) with spectral soft masking
- **Method**: Median filtering to create soft masks separating vocals from instrumental
- **Fallback**: If separation fails, uses original as instrumental with silent vocal track
- **Design Decision**: No ML model dependencies, runs entirely in-memory
- **Trade-off**: Lower quality separation compared to ML-based approaches like Spleeter/Demucs
- **Future Enhancement Path**: Integration with Spleeter or Demucs for production-quality separation

**Instrumental Extension Strategy**:
- **Problem**: Parody lyrics often exceed original song length
- **Solution**: BPM detection and intelligent looping on bar boundaries
- **Implementation**: 
  - Detects BPM using librosa beat tracking
  - Calculates bars in original (4/4 time signature assumed)
  - Loops on bar boundaries to maintain rhythm
  - Adds fade-out at end for smooth finish
- **Duration Estimation**: Word count ÷ (BPM × 2.5 / 60) × 1.2 buffer

## Voice Synthesis System

**Voice Bank Configuration**:
- **Technology**: OpenAI Text-to-Speech API (tts-1 model)
- **Voice Mapping**: Role-based voice assignment
  - Male quartet → onyx (with quartet effect)
  - Single Female → nova (pitch +2)
  - Solo Female → shimmer
  - Male → echo
  - Male bass → onyx (slower, pitch -3)
  - Default → alloy
- **Special Effects**: 
  - Quartet simulation through pitch shifting (±0.3 semitones) and timing offsets (15-25ms)
  - Speed adjustments per role (e.g., 0.95x for bass)
  - Multi-track mixing for harmony effects
  - 500ms gaps between sections with 200ms crossfades

**Lyric Annotation Format**:
```
[Section](Role) Lyrics text
```
- **Example**: `[Verse 1](Male quartet) Who made you fear the stranger on the street?`
- **Design Decision**: Inline annotations for easy editing without separate config files
- **Supported Roles**: Male quartet, Single Female, Male bass, Solo Female, Male, Female, Default
- **Parser**: Regex-based extraction (`\[([^\]]+)\]\(([^\)]+)\)`) with inline marker cleanup
- **Inline Markers**: Automatically removes role keywords in parentheses while keeping lyrics like "(Ha!)"

## Audio Processing Pipeline

**Technology Stack**:
- **Librosa**: Audio analysis, BPM detection, HPSS separation, spectral processing
- **Pydub**: Audio segment manipulation, volume adjustment, mixing, export
- **Soundfile**: Audio I/O operations for wav files
- **NumPy**: Numerical processing for audio arrays and spectral masking
- **FFmpeg**: Audio encoding (via pydub backend)

**Processing Flow**:
1. **Load audio** → Upload file or download from YouTube (yt-dlp)
2. **Separate vocals/instrumental** → Spectral masking with HPSS
3. **Detect BPM** → Librosa beat tracking on instrumental
4. **Estimate duration** → Word count analysis with BPM adjustment
5. **Extend instrumental** → Bar-aligned looping if parody is longer
6. **Parse lyrics** → Extract sections with role annotations
7. **Generate vocals** → OpenAI TTS per section with role-specific voices
8. **Apply effects** → Quartet simulation, pitch shifts, timing offsets
9. **Combine sections** → Merge vocal sections with crossfades
10. **Mix final output** → Overlay vocals on instrumental with volume controls

# External Dependencies

## Third-Party APIs

**OpenAI API**:
- **Purpose**: Text-to-speech voice generation
- **Authentication**: OPENAI_API_KEY environment variable
- **Model**: tts-1 (standard quality, faster) or tts-1-hd (higher quality)
- **Voices Used**: alloy, echo, fable, onyx, nova, shimmer
- **Cost Model**: Pay-per-use based on character count (~$15 per 1M characters)
- **Rate Limits**: Apply standard OpenAI API rate limits

## External Tools

**yt-dlp**:
- **Purpose**: YouTube audio download functionality
- **Installation**: Installed via Python package manager
- **Usage**: `yt-dlp -f bestaudio/best --extract-audio --audio-format wav`
- **Format**: Extracts best audio quality, converts to WAV for processing
- **Timeout**: 120 seconds per download

**FFmpeg**:
- **Purpose**: Audio encoding/decoding backend for pydub
- **Installation**: System package via Nix
- **Usage**: Automatic via pydub for format conversions and mixing

**Optional ML Models** (for future enhancement):
- **Spleeter**: High-quality vocal separation (not currently integrated)
- **Demucs**: Alternative vocal separation model with better quality
- **Trade-off**: Current implementation prioritizes simplicity and speed over separation quality

## Python Libraries

**Core Audio Processing**:
- `librosa==0.11.0`: Audio analysis and feature extraction
- `soundfile==0.13.1`: Audio file I/O
- `pydub==0.25.1`: Audio manipulation and format conversion
- `numpy>=1.20`: Numerical operations
- `scipy>=1.16`: Scientific computing for audio processing

**Web Framework**:
- `streamlit>=1.0`: Web application framework
- `openai>=1.0`: OpenAI API client

**Utilities**:
- `yt-dlp>=2025.10`: YouTube download
- `pathlib`: File path operations (built-in)
- `subprocess`: External tool execution (built-in)
- `tempfile`: Temporary file management (built-in)

## File Storage

**Temporary File Management**:
- **Location**: `/tmp/parody_generator/` directory
- **Lifecycle**: Created during processing, persists until system temp cleanup
- **Structure**: 
  - `vocals.wav` - Separated vocal track
  - `instrumental.wav` - Separated instrumental track
  - `instrumental_extended.wav` - Extended instrumental if needed
  - `section_N_*.mp3` - Individual vocal sections
  - `section_N_quartet.wav` - Quartet effect vocals
  - `combined_vocals.wav` - All sections merged
  - `parody_final.mp3` - Final mixed output
- **Cleanup**: Manual cleanup not implemented (relies on OS temp cleanup)

# Project Structure

```
.
├── app.py                  # Main Streamlit application
├── audio_processor.py      # Audio processing (separation, BPM, extension, mixing)
├── lyric_parser.py        # Role-based lyric parsing
├── voice_generator.py     # OpenAI TTS integration and voice bank
├── replit.md              # This documentation file
└── .streamlit/
    └── config.toml        # Streamlit configuration
```

# Future Enhancements

Planned features for next phase:
- Advanced vocal role separation with individual volume and pan controls per role
- AI-powered lyric generation with theme selection and custom prompts
- Beat-aligned vocal timing using forced alignment tools (aeneas, gentle)
- Additional voice models and voice cloning capabilities
- Visual waveform editor for fine-tuning vocal placement and timing
