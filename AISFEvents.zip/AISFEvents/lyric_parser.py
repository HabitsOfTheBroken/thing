"""
Lyric parser for role-aware vocal arrangement
Parses annotations like [Verse 1](Male quartet) and [Chorus](Single Female)
"""

import re
from typing import List, Dict, Tuple
from dataclasses import dataclass


@dataclass
class VocalSection:
    """Represents a section of lyrics with role information"""
    section_type: str  # e.g., "Verse 1", "Chorus", "Bridge"
    role: str  # e.g., "Male quartet", "Single Female"
    lyrics: str  # The actual lyrics for this section
    start_word_index: int  # Position in overall lyrics
    

class LyricParser:
    """Parses role-based lyric annotations"""
    
    def __init__(self):
        # Pattern to match [Section](Role) at the start of a line
        self.section_pattern = re.compile(r'\[([^\]]+)\]\(([^\)]+)\)', re.IGNORECASE)
        
        # Pattern to match inline role changes like (Single Female) within text
        self.inline_role_pattern = re.compile(r'\(([^)]+(?:Female|Male|quartet|bass|solo)[^)]*)\)', re.IGNORECASE)
    
    def parse_lyrics(self, lyrics: str) -> List[VocalSection]:
        """
        Parse lyrics with role annotations into structured sections
        
        Example input:
        [Verse 1](Male quartet) Who made you fear the stranger on the street?
        [Chorus](Single Female) It's the Amygdala all along!
        
        Returns list of VocalSection objects
        """
        sections = []
        
        # Find all section markers
        matches = list(self.section_pattern.finditer(lyrics))
        
        if not matches:
            # No role annotations found, treat entire text as single section
            return [VocalSection(
                section_type="Full Song",
                role="Default",
                lyrics=lyrics.strip(),
                start_word_index=0
            )]
        
        for i, match in enumerate(matches):
            section_type = match.group(1).strip()
            role = match.group(2).strip()
            
            # Extract lyrics for this section
            # Start right after the [Section](Role) marker
            start_pos = match.end()
            
            # End at the next section marker (or end of text)
            if i < len(matches) - 1:
                end_pos = matches[i + 1].start()
            else:
                end_pos = len(lyrics)
            
            # Get the lyrics between markers
            section_lyrics = lyrics[start_pos:end_pos].strip()
            
            # Clean up lyrics - remove inline role annotations that are just markers
            section_lyrics = self._clean_inline_markers(section_lyrics)
            
            # Skip if no lyrics after cleaning
            if not section_lyrics:
                continue
            
            # Count words before this section
            words_before = len(re.findall(r'\b\w+\b', lyrics[:start_pos]))
            
            sections.append(VocalSection(
                section_type=section_type,
                role=role,
                lyrics=section_lyrics,
                start_word_index=words_before
            ))
        
        return sections
    
    def _clean_inline_markers(self, text: str) -> str:
        """Remove inline role markers and comments from lyrics"""
        # Remove comments like *lol don't put that in
        text = re.sub(r'\*[^*\n]+(?:\*|$)', '', text)
        
        # Remove standalone role markers (but keep actual lyrics in parentheses like "(Ha!)")
        # Only remove if it contains role keywords
        role_keywords = ['quartet', 'male', 'female', 'bass', 'solo', 'single', 'married', 'high tone', 'low', 'lowest']
        
        def should_remove(match):
            content = match.group(1).lower()
            return any(keyword in content for keyword in role_keywords)
        
        # Find all parenthetical expressions
        text = re.sub(
            r'\(([^)]+)\)',
            lambda m: '' if should_remove(m) else m.group(0),
            text
        )
        
        # Clean up extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def extract_plain_lyrics(self, lyrics: str) -> str:
        """Extract just the lyrics without any role annotations"""
        sections = self.parse_lyrics(lyrics)
        plain_lyrics = ' '.join(section.lyrics for section in sections)
        return plain_lyrics.strip()
    
    def get_role_distribution(self, lyrics: str) -> Dict[str, int]:
        """Get count of how many sections each role sings"""
        sections = self.parse_lyrics(lyrics)
        distribution = {}
        
        for section in sections:
            role = self._normalize_role_name(section.role)
            distribution[role] = distribution.get(role, 0) + 1
        
        return distribution
    
    def _normalize_role_name(self, role: str) -> str:
        """Normalize role names for consistency"""
        role_lower = role.lower().strip()
        
        if 'quartet' in role_lower and 'male' in role_lower:
            return "Male quartet"
        elif 'female' in role_lower and ('single' in role_lower or 'solo' in role_lower):
            return "Single Female"
        elif 'female' in role_lower:
            return "Female"
        elif 'male' in role_lower and 'bass' in role_lower:
            return "Male bass"
        elif 'male' in role_lower:
            return "Male"
        else:
            return role.strip()
    
    def split_by_sections(self, lyrics: str) -> List[Tuple[str, str, str]]:
        """
        Split lyrics into sections with their roles
        Returns list of (section_type, role, lyrics) tuples
        """
        sections = self.parse_lyrics(lyrics)
        return [(s.section_type, s.role, s.lyrics) for s in sections]
