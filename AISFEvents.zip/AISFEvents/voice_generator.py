"""
Multi-voice TTS system using OpenAI's text-to-speech API
Handles different vocal roles with voice bank configuration
"""

import os
from pathlib import Path
import tempfile
from typing import Dict, List, Optional
from openai import OpenAI
from pydub import AudioSegment


class VoiceBank:
    """Configuration for different vocal roles"""
    
    # Voice bank mapping roles to OpenAI TTS voices and settings
    # OpenAI TTS voices: alloy, echo, fable, onyx, nova, shimmer
    VOICE_CONFIGS = {
        "Male quartet": {
            "voice": "onyx",  # Deep male voice
            "speed": 1.0,
            "pitch_shift": 0,  # Will be modified per voice in quartet
            "apply_quartet_effect": True
        },
        "Single Female": {
            "voice": "nova",  # Clear female voice
            "speed": 1.0,
            "pitch_shift": 2,  # Slightly higher
            "apply_quartet_effect": False
        },
        "Female": {
            "voice": "nova",
            "speed": 1.0,
            "pitch_shift": 0,
            "apply_quartet_effect": False
        },
        "Solo Female": {
            "voice": "shimmer",  # Different female voice
            "speed": 1.0,
            "pitch_shift": 0,
            "apply_quartet_effect": False
        },
        "Male": {
            "voice": "echo",  # Male voice
            "speed": 1.0,
            "pitch_shift": 0,
            "apply_quartet_effect": False
        },
        "Male bass": {
            "voice": "onyx",
            "speed": 0.95,  # Slower for bass
            "pitch_shift": -3,  # Lower pitch
            "apply_quartet_effect": False
        },
        "Default": {
            "voice": "alloy",  # Neutral voice
            "speed": 1.0,
            "pitch_shift": 0,
            "apply_quartet_effect": False
        }
    }
    
    @classmethod
    def get_config(cls, role: str) -> Dict:
        """Get voice configuration for a specific role"""
        # Normalize role name
        role_normalized = role.strip()
        
        # Try exact match first
        if role_normalized in cls.VOICE_CONFIGS:
            return cls.VOICE_CONFIGS[role_normalized].copy()
        
        # Try partial matches
        role_lower = role_normalized.lower()
        for key in cls.VOICE_CONFIGS:
            if key.lower() in role_lower or role_lower in key.lower():
                return cls.VOICE_CONFIGS[key].copy()
        
        # Default fallback
        return cls.VOICE_CONFIGS["Default"].copy()


class VoiceGenerator:
    """Generates speech using OpenAI TTS with role-based voices"""
    
    def __init__(self):
        # Reference to the OpenAI integration blueprint:
        # the newest OpenAI model is "gpt-5" which was released August 7, 2025.
        # do not change this unless explicitly requested by the user
        self.client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
        self.temp_dir = Path(tempfile.gettempdir()) / "parody_generator"
        self.temp_dir.mkdir(exist_ok=True)
    
    def generate_voice(
        self, 
        text: str, 
        role: str,
        output_filename: Optional[str] = None
    ) -> str:
        """
        Generate voice for given text using role-specific voice
        Returns path to generated audio file
        """
        # Get voice configuration for this role
        config = VoiceBank.get_config(role)
        
        # Generate filename if not provided
        if output_filename is None:
            output_filename = f"voice_{role.replace(' ', '_')}_{hash(text) % 10000}.mp3"
        
        output_path = self.temp_dir / output_filename
        
        # Generate speech using OpenAI TTS
        try:
            response = self.client.audio.speech.create(
                model="tts-1",  # or "tts-1-hd" for higher quality
                voice=config["voice"],
                input=text,
                speed=config["speed"]
            )
            
            # Save to file
            response.stream_to_file(str(output_path))
            
            return str(output_path)
            
        except Exception as e:
            print(f"Error generating voice: {e}")
            raise
    
    def generate_section_vocals(
        self,
        sections: List[tuple],  # List of (section_type, role, lyrics)
        audio_processor
    ) -> List[Dict]:
        """
        Generate vocals for all sections with appropriate voices
        Returns list of dicts with section info and audio paths
        """
        generated_sections = []
        
        for i, (section_type, role, lyrics) in enumerate(sections):
            if not lyrics.strip():
                continue
            
            print(f"Generating vocals for {section_type} ({role})...")
            
            # Generate base vocal
            vocal_path = self.generate_voice(
                text=lyrics,
                role=role,
                output_filename=f"section_{i}_{section_type.replace(' ', '_')}.mp3"
            )
            
            # Check if quartet effect should be applied
            config = VoiceBank.get_config(role)
            
            if config.get("apply_quartet_effect", False):
                # Convert to wav for processing
                audio = AudioSegment.from_file(vocal_path)
                wav_path = str(self.temp_dir / f"section_{i}_temp.wav")
                audio.export(wav_path, format="wav")
                
                # Apply quartet effect
                quartet_path = str(self.temp_dir / f"section_{i}_quartet.wav")
                vocal_path = audio_processor.create_quartet_effect(wav_path, quartet_path)
            
            generated_sections.append({
                "section_type": section_type,
                "role": role,
                "lyrics": lyrics,
                "audio_path": vocal_path
            })
        
        return generated_sections
    
    def combine_section_vocals(
        self, 
        sections: List[Dict],
        output_path: str
    ) -> str:
        """
        Combine multiple vocal sections into one continuous track
        Adds smooth transitions between sections
        """
        if not sections:
            raise ValueError("No sections to combine")
        
        # Load first section
        combined = AudioSegment.from_file(sections[0]["audio_path"])
        
        # Add remaining sections with small gaps for breathing
        for section in sections[1:]:
            # Add a small silence between sections (500ms)
            silence = AudioSegment.silent(duration=500)
            section_audio = AudioSegment.from_file(section["audio_path"])
            
            # Add crossfade between sections (200ms)
            combined = combined.append(silence, crossfade=0)
            combined = combined.append(section_audio, crossfade=200)
        
        # Export combined vocals
        combined.export(output_path, format="wav")
        
        return output_path
