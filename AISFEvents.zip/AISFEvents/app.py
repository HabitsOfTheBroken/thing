"""
Weird Al Parody Generator - Streamlit Web Application
Advanced music parody generator with intelligent instrumental extension and multi-voice support
"""

import streamlit as st
import os
import tempfile
from pathlib import Path
import subprocess
from typing import Optional
import base64

from audio_processor import AudioProcessor
from lyric_parser import LyricParser
from voice_generator import VoiceGenerator


def download_youtube_audio(url: str, output_dir: Path) -> Optional[str]:
    """Download audio from YouTube URL"""
    try:
        output_template = str(output_dir / "youtube_audio.%(ext)s")
        
        cmd = [
            'yt-dlp',
            '-f', 'bestaudio/best',
            '--extract-audio',
            '--audio-format', 'wav',
            '-o', output_template,
            url
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        if result.returncode == 0:
            # Find the downloaded file
            audio_files = list(output_dir.glob("youtube_audio.*"))
            if audio_files:
                return str(audio_files[0])
        
        return None
    except Exception as e:
        st.error(f"Error downloading YouTube audio: {e}")
        return None


def get_audio_download_link(file_path: str, filename: str) -> str:
    """Generate download link for audio file"""
    with open(file_path, 'rb') as f:
        audio_bytes = f.read()
    b64 = base64.b64encode(audio_bytes).decode()
    return f'<a href="data:audio/mp3;base64,{b64}" download="{filename}">Download {filename}</a>'


def main():
    st.set_page_config(
        page_title="Weird Al Parody Generator",
        page_icon="🎵",
        layout="wide"
    )
    
    # Custom CSS for better styling
    st.markdown("""
        <style>
        .main-header {
            font-size: 3rem;
            font-weight: bold;
            text-align: center;
            color: #FF6B35;
            margin-bottom: 1rem;
        }
        .sub-header {
            font-size: 1.2rem;
            text-align: center;
            color: #666;
            margin-bottom: 2rem;
        }
        .success-box {
            padding: 1rem;
            border-radius: 0.5rem;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        </style>
    """, unsafe_allow_html=True)
    
    # Header
    st.markdown('<div class="main-header">🎵 Weird Al Parody Generator 🎵</div>', unsafe_allow_html=True)
    st.markdown('<div class="sub-header">AI-powered music parody creation with intelligent multi-voice arrangement</div>', unsafe_allow_html=True)
    
    # Initialize session state
    if 'generated_parody' not in st.session_state:
        st.session_state.generated_parody = None
    if 'processing' not in st.session_state:
        st.session_state.processing = False
    
    # Initialize processors
    audio_processor = AudioProcessor()
    lyric_parser = LyricParser()
    voice_generator = VoiceGenerator()
    
    # Main layout with two columns
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("### 🎼 Step 1: Source Music")
        
        # Audio input options
        input_method = st.radio(
            "Choose input method:",
            ["Upload Audio File", "YouTube URL"],
            horizontal=True
        )
        
        audio_file_path = None
        
        if input_method == "Upload Audio File":
            uploaded_file = st.file_uploader(
                "Upload your source music",
                type=['mp3', 'wav', 'm4a', 'flac', 'ogg'],
                help="Upload the original song you want to parody"
            )
            
            if uploaded_file:
                # Save uploaded file
                temp_dir = Path(tempfile.gettempdir()) / "parody_generator"
                temp_dir.mkdir(exist_ok=True)
                audio_file_path = temp_dir / f"uploaded_{uploaded_file.name}"
                
                with open(audio_file_path, 'wb') as f:
                    f.write(uploaded_file.read())
                
                st.success(f"✅ Uploaded: {uploaded_file.name}")
        
        else:  # YouTube URL
            youtube_url = st.text_input(
                "Enter YouTube URL",
                placeholder="https://www.youtube.com/watch?v=..."
            )
            
            if youtube_url and st.button("📥 Download Audio"):
                with st.spinner("Downloading audio from YouTube..."):
                    temp_dir = Path(tempfile.gettempdir()) / "parody_generator"
                    temp_dir.mkdir(exist_ok=True)
                    audio_file_path = download_youtube_audio(youtube_url, temp_dir)
                    
                    if audio_file_path:
                        st.success("✅ Audio downloaded successfully!")
                    else:
                        st.error("❌ Failed to download audio. Please check the URL.")
    
    with col2:
        st.markdown("### 📝 Step 2: Parody Lyrics")
        
        st.info("""
        **Pro tip:** Use role annotations to specify different singers!
        
        Example format:
        ```
        [Verse 1](Male quartet) Your lyrics here...
        [Chorus](Single Female) More lyrics...
        [Bridge](Solo Female) Even more lyrics...
        ```
        
        Supported roles: Male quartet, Single Female, Solo Female, Male, Female, Male bass
        """)
        
        parody_lyrics = st.text_area(
            "Enter your parody lyrics",
            height=400,
            placeholder="""[Verse 1](Male quartet) Who made you fear the stranger on the street?
[Chorus](Single Female) It's the Amygdala all along! Ha, ha!
[Verse 2](Male quartet) Who let the Nazis do what they did?
[Bridge](Solo Female) It points at them and says "That's the threat!"
[Final Chorus](Male quartet) Who's been messing with your head?!""",
            help="Write your parody lyrics with role annotations for multi-voice arrangement"
        )
        
        # Show parsed structure
        if parody_lyrics.strip():
            with st.expander("📊 View Parsed Structure"):
                sections = lyric_parser.parse_lyrics(parody_lyrics)
                for i, section in enumerate(sections):
                    st.write(f"**{section.section_type}** ({section.role})")
                    st.write(f"_{section.lyrics[:100]}..._" if len(section.lyrics) > 100 else f"_{section.lyrics}_")
                    st.divider()
    
    # Advanced options
    st.markdown("### ⚙️ Advanced Options")
    
    adv_col1, adv_col2 = st.columns(2)
    
    with adv_col1:
        vocal_volume = st.slider(
            "Vocal Volume (dB)",
            min_value=-10,
            max_value=10,
            value=0,
            help="Adjust how loud the vocals are in the final mix"
        )
    
    with adv_col2:
        instrumental_volume = st.slider(
            "Instrumental Volume (dB)",
            min_value=-10,
            max_value=10,
            value=-3,
            help="Adjust how loud the instrumental is in the final mix"
        )
    
    # Generate button
    st.markdown("---")
    
    if st.button("🎵 Generate Parody", type="primary", use_container_width=True):
        if not audio_file_path or not os.path.exists(str(audio_file_path)):
            st.error("❌ Please upload or download source music first!")
        elif not parody_lyrics.strip():
            st.error("❌ Please enter your parody lyrics!")
        else:
            # Start generation process
            st.session_state.processing = True
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                # Step 1: Separate vocals and instrumental
                status_text.text("🎵 Step 1/6: Separating vocals from instrumental...")
                progress_bar.progress(10)
                
                separation_result = audio_processor.separate_vocals(str(audio_file_path))
                
                if not separation_result["success"]:
                    st.error(f"❌ Vocal separation failed: {separation_result['error']}")
                    st.session_state.processing = False
                    st.stop()
                
                instrumental_path = separation_result["instrumental"]
                
                # Step 2: Detect BPM
                status_text.text("🥁 Step 2/6: Detecting BPM and analyzing timing...")
                progress_bar.progress(20)
                
                bpm = audio_processor.detect_bpm(instrumental_path)
                st.info(f"🎵 Detected BPM: {bpm:.1f}")
                
                # Step 3: Estimate duration and extend instrumental if needed
                status_text.text("⏱️ Step 3/6: Extending instrumental to match lyrics...")
                progress_bar.progress(30)
                
                estimated_duration = audio_processor.estimate_lyrics_duration(parody_lyrics, bpm)
                current_duration = audio_processor.get_audio_duration(instrumental_path)
                
                st.info(f"📏 Original duration: {current_duration:.1f}s | Required: {estimated_duration:.1f}s")
                
                if estimated_duration > current_duration:
                    instrumental_path = audio_processor.extend_instrumental(
                        instrumental_path,
                        estimated_duration,
                        bpm
                    )
                    st.success(f"✅ Instrumental extended to {estimated_duration:.1f} seconds")
                
                # Step 4: Parse lyrics into sections
                status_text.text("📖 Step 4/6: Parsing lyric structure and roles...")
                progress_bar.progress(40)
                
                sections = lyric_parser.split_by_sections(parody_lyrics)
                st.info(f"🎭 Found {len(sections)} vocal sections")
                
                # Step 5: Generate multi-voice vocals
                status_text.text("🎤 Step 5/6: Generating multi-voice vocals with AI...")
                progress_bar.progress(50)
                
                generated_sections = voice_generator.generate_section_vocals(
                    sections,
                    audio_processor
                )
                
                # Combine all vocal sections
                temp_dir = Path(tempfile.gettempdir()) / "parody_generator"
                combined_vocals_path = str(temp_dir / "combined_vocals.wav")
                
                voice_generator.combine_section_vocals(generated_sections, combined_vocals_path)
                
                progress_bar.progress(80)
                
                # Step 6: Mix everything together
                status_text.text("🎚️ Step 6/6: Mixing final parody track...")
                
                output_path = str(temp_dir / "parody_final.mp3")
                
                mix_result = audio_processor.mix_audio_tracks(
                    instrumental_path,
                    combined_vocals_path,
                    output_path,
                    vocal_volume_db=vocal_volume,
                    instrumental_volume_db=instrumental_volume
                )
                
                progress_bar.progress(100)
                
                if mix_result["success"]:
                    status_text.text("✅ Parody generation complete!")
                    st.session_state.generated_parody = output_path
                    st.balloons()
                else:
                    st.error(f"❌ Mixing failed: {mix_result['error']}")
                
            except Exception as e:
                st.error(f"❌ Error during generation: {str(e)}")
                import traceback
                st.code(traceback.format_exc())
            
            finally:
                st.session_state.processing = False
    
    # Display results
    if st.session_state.generated_parody and os.path.exists(st.session_state.generated_parody):
        st.markdown("---")
        st.markdown("### 🎉 Your Parody is Ready!")
        
        # Audio player
        st.audio(st.session_state.generated_parody, format='audio/mp3')
        
        # Download button
        with open(st.session_state.generated_parody, 'rb') as f:
            st.download_button(
                label="💾 Download Parody",
                data=f,
                file_name="weird_al_parody.mp3",
                mime="audio/mp3",
                use_container_width=True
            )
    
    # Footer
    st.markdown("---")
    st.markdown("""
        <div style="text-align: center; color: #666; padding: 2rem;">
            <p><strong>Weird Al Parody Generator</strong> - Create professional music parodies with AI</p>
            <p>Powered by OpenAI TTS, Librosa, and PyDub</p>
        </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
