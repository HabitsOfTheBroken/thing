"""
Core audio processing modules for the Weird Al Parody Generator
Handles vocal separation, BPM detection, and intelligent instrumental extension
"""

import os
import tempfile
import re
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any
import numpy as np
from pydub import AudioSegment
import librosa
import soundfile as sf


class AudioProcessor:
    """Handles all audio processing operations"""
    
    def __init__(self):
        self.temp_dir = Path(tempfile.gettempdir()) / "parody_generator"
        self.temp_dir.mkdir(exist_ok=True)
    
    def separate_vocals(self, audio_path: str) -> Dict[str, Any]:
        """
        Separate vocals from instrumental using audio processing
        Returns paths to vocals and instrumental tracks
        
        Uses spectral filtering to separate vocals from instrumental.
        For production use, integrate Spleeter, Demucs, or similar ML models.
        """
        try:
            # Load audio with librosa for processing
            y, sr = librosa.load(audio_path, sr=None)
            
            # Separate harmonic (instrumental) and percussive components
            # Vocals tend to be harmonic, so we'll use HPSS
            y_harmonic, y_percussive = librosa.effects.hpss(y)
            
            # Create a rough vocal separation using spectral masking
            # This is a simplified approach - vocals typically in mid-frequency range
            stft = librosa.stft(y)
            
            # Estimate foreground (vocals) using median filtering
            # This creates a soft mask to separate vocals from background
            S_filter = librosa.decompose.nn_filter(
                np.abs(stft),
                aggregate=np.median,
                metric='cosine',
                width=int(librosa.time_to_frames(2, sr=sr))
            )
            
            S_filter = np.minimum(np.abs(stft), S_filter)
            
            # Create soft masks for vocals and instrumental
            margin_v = 2  # margin for vocal separation
            margin_i = 10  # margin for instrumental separation
            
            mask_v = librosa.util.softmask(
                np.abs(stft) - S_filter,
                margin_v * S_filter,
                power=2
            )
            
            mask_i = librosa.util.softmask(
                S_filter,
                margin_i * (np.abs(stft) - S_filter),
                power=2
            )
            
            # Apply masks
            stft_vocals = mask_v * stft
            stft_instrumental = mask_i * stft
            
            # Convert back to audio
            y_vocals = librosa.istft(stft_vocals)
            y_instrumental = librosa.istft(stft_instrumental)
            
            # Export separated tracks
            vocals_path = str(self.temp_dir / "vocals.wav")
            instrumental_path = str(self.temp_dir / "instrumental.wav")
            
            sf.write(vocals_path, y_vocals, sr)
            sf.write(instrumental_path, y_instrumental, sr)
            
            return {
                "success": True,
                "vocals": vocals_path,
                "instrumental": instrumental_path,
                "method": "spectral_separation"
            }
            
        except Exception as e:
            print(f"Spectral separation failed: {e}")
            # Fallback: at least provide the original as instrumental
            # This is better than duplicating to both
            try:
                audio = AudioSegment.from_file(audio_path)
                instrumental_path = str(self.temp_dir / "instrumental.wav")
                vocals_path = str(self.temp_dir / "vocals_placeholder.wav")
                
                # Export original as instrumental
                audio.export(instrumental_path, format="wav")
                
                # Create silent placeholder for vocals
                silent = AudioSegment.silent(duration=len(audio))
                silent.export(vocals_path, format="wav")
                
                return {
                    "success": True,
                    "vocals": vocals_path,
                    "instrumental": instrumental_path,
                    "method": "fallback",
                    "warning": "Separation failed, using original as instrumental"
                }
            except Exception as e2:
                return {"success": False, "error": str(e2)}
    
    def detect_bpm(self, audio_path: str) -> float:
        """Detect BPM (beats per minute) of the audio track"""
        try:
            y, sr = librosa.load(audio_path, duration=60)
            tempo, _ = librosa.beat.beat_track(y=y, sr=sr)
            return float(tempo)
        except Exception as e:
            print(f"BPM detection failed: {e}, using default 120 BPM")
            return 120.0
    
    def estimate_lyrics_duration(self, lyrics: str, bpm: float = 120.0) -> float:
        """
        Estimate duration needed for lyrics based on word count and BPM
        Uses intelligent word-based timing instead of simple line count
        """
        words = re.findall(r'\b\w+\b', lyrics)
        total_words = len(words)
        
        # Adjust words per second based on tempo
        # Faster songs = more words per second
        words_per_minute = bpm * 2.5
        words_per_second = words_per_minute / 60
        
        estimated_duration = total_words / words_per_second
        
        # Add buffer for musical breaks, intros, outros (20%)
        estimated_duration *= 1.2
        
        return estimated_duration
    
    def extend_instrumental(
        self, 
        instrumental_path: str, 
        target_duration: float,
        bpm: float
    ) -> str:
        """
        Intelligently extend instrumental track to match target duration
        Uses BPM-aware looping to keep rhythm intact
        """
        try:
            # Load instrumental
            audio = AudioSegment.from_file(instrumental_path)
            current_duration = len(audio) / 1000.0  # Convert to seconds
            
            if current_duration >= target_duration:
                return instrumental_path
            
            # Calculate how many times to loop based on BPM
            # We want to loop on bar boundaries (assuming 4/4 time)
            seconds_per_beat = 60.0 / bpm
            seconds_per_bar = seconds_per_beat * 4
            
            # Round current duration to nearest bar
            bars_in_original = round(current_duration / seconds_per_bar)
            bar_aligned_duration = bars_in_original * seconds_per_bar * 1000  # ms
            
            # Trim to bar boundary for clean looping
            audio_trimmed = audio[:int(bar_aligned_duration)]
            
            # Calculate repeat count
            repeat_count = int((target_duration * 1000) / len(audio_trimmed)) + 1
            
            # Loop the audio
            extended_audio = audio_trimmed * repeat_count
            
            # Trim to exact target duration
            extended_audio = extended_audio[:int(target_duration * 1000)]
            
            # Add fade out at the end (last 2 seconds)
            fade_duration = min(2000, len(extended_audio) // 4)
            extended_audio = extended_audio.fade_out(fade_duration)
            
            # Export extended instrumental
            extended_path = str(self.temp_dir / "instrumental_extended.wav")
            extended_audio.export(extended_path, format="wav")
            
            return extended_path
            
        except Exception as e:
            print(f"Error extending instrumental: {e}")
            return instrumental_path
    
    def get_audio_duration(self, audio_path: str) -> float:
        """Get duration of audio file in seconds"""
        try:
            audio = AudioSegment.from_file(audio_path)
            return len(audio) / 1000.0
        except Exception as e:
            print(f"Error getting audio duration: {e}")
            return 0.0
    
    def mix_audio_tracks(
        self, 
        instrumental_path: str, 
        vocals_path: str,
        output_path: str,
        vocal_volume_db: int = 0,
        instrumental_volume_db: int = -3
    ) -> Dict:
        """
        Mix instrumental and vocals together
        Returns success status and output path
        """
        try:
            # Load tracks
            instrumental = AudioSegment.from_file(instrumental_path)
            vocals = AudioSegment.from_file(vocals_path)
            
            # Adjust volumes
            instrumental = instrumental + instrumental_volume_db
            vocals = vocals + vocal_volume_db
            
            # Mix by overlaying vocals on instrumental
            # If vocals are shorter, instrumental continues
            mixed = instrumental.overlay(vocals, position=0)
            
            # Export final mix
            mixed.export(output_path, format="mp3", bitrate="192k")
            
            return {
                "success": True,
                "output_path": output_path
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def create_quartet_effect(
        self, 
        vocal_path: str, 
        output_path: str
    ) -> str:
        """
        Create quartet effect from single vocal track
        Uses pitch shifting, timing offsets, and panning to simulate 4 voices
        """
        try:
            # Load the vocal track
            audio = AudioSegment.from_file(vocal_path)
            
            # Create 4 variations with different characteristics
            variations = []
            
            # Voice 1: Original, panned left (-60%)
            voice1 = audio
            variations.append(voice1)
            
            # Voice 2: Slight pitch up, slight delay
            voice2 = self._pitch_shift(audio, semitones=0.3)
            voice2 = AudioSegment.silent(duration=15) + voice2  # 15ms delay
            variations.append(voice2)
            
            # Voice 3: Slight pitch down, slight delay
            voice3 = self._pitch_shift(audio, semitones=-0.3)
            voice3 = AudioSegment.silent(duration=25) + voice3  # 25ms delay
            variations.append(voice3)
            
            # Voice 4: Original pitch, slight delay
            voice4 = audio
            voice4 = AudioSegment.silent(duration=20) + voice4  # 20ms delay
            variations.append(voice4)
            
            # Mix all voices together
            mixed = variations[0]
            for voice in variations[1:]:
                # Ensure all tracks are same length before overlaying
                max_len = max(len(mixed), len(voice))
                mixed = mixed + AudioSegment.silent(duration=max_len - len(mixed))
                voice = voice + AudioSegment.silent(duration=max_len - len(voice))
                mixed = mixed.overlay(voice)
            
            # Reduce volume to prevent clipping
            mixed = mixed - 3
            
            # Export
            mixed.export(output_path, format="wav")
            return output_path
            
        except Exception as e:
            print(f"Error creating quartet effect: {e}")
            return vocal_path
    
    def _pitch_shift(self, audio: AudioSegment, semitones: float) -> AudioSegment:
        """Pitch shift audio by semitones"""
        # Convert semitones to playback speed ratio
        # 12 semitones = 2x speed (one octave)
        playback_speed = 2 ** (semitones / 12.0)
        
        # Change frame rate (which changes pitch and speed)
        shifted = audio._spawn(
            audio.raw_data,
            overrides={'frame_rate': int(audio.frame_rate * playback_speed)}
        )
        
        # Convert back to original frame rate (keeps pitch change, fixes speed)
        return shifted.set_frame_rate(audio.frame_rate)
